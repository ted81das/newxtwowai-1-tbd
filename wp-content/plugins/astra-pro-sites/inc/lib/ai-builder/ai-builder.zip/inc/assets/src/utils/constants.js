export const SESSION_STORAGE_KEY = 'st-ai-builder';

export const MB_IN_BYTE = 1e6;

export const WEEKS_IN_SECONDS = 14 * 24 * 60 * 60;
